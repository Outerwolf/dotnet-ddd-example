﻿namespace Security.Auth.Application;

public class Class1
{
}