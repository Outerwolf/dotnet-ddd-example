﻿namespace Security.Auth.Domain;

public class Class1
{
}