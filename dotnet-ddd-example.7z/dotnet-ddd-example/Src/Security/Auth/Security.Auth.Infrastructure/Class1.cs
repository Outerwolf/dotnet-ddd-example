﻿namespace Security.Auth.Infrastructure;

public class Class1
{
}