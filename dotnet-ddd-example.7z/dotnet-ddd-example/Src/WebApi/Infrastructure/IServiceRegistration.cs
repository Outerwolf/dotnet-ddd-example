﻿namespace WebApi.Infrastructure;

public class IServiceRegistration
{
    
}