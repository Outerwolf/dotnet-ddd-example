﻿namespace WebApi.Infrastructure;

public class ServiceRegistrations
{
    
}